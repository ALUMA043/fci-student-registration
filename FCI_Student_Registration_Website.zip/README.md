# FCI Student Registration Website

A browser-based version of the Java Swing `FCI` student registration form.

## Files
- `index.html` — form structure and navigation
- `style.css` — responsive styling
- `script.js` — menu, submit, reset, and exit-confirmation behavior

## Run locally
Open `index.html` in a modern browser.

## Publish with GitHub Pages
1. Open your GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js` to the repository root (the same level as this README).
3. Commit the changes to your publishing branch, usually `main`.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch `main` and folder `/(root)`, then click **Save**.
7. Wait for the deployment workflow to finish and use the **Visit site** link.

## Important behavior notes
- Submit validates the required fields and displays a registration summary in the browser.
- Reset clears the form and result.
- Exit asks for confirmation. Browsers generally prevent websites from closing a tab they did not open, so confirming Exit clears the form and explains that the user can close the tab.
- The form does not send data to a server or save it to a database. GitHub Pages is static hosting; add a separate backend if registrations must be stored or sent to an administrator.
