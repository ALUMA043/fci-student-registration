const form = document.getElementById("registrationForm");
const firstName = document.getElementById("fname");
const lastName = document.getElementById("lname");
const program = document.getElementById("program");
const statusMessage = document.getElementById("statusMessage");
const submissionResult = document.getElementById("submissionResult");
const exitButton = document.getElementById("exitButton");
const programsButton = document.getElementById("programsButton");
const programsMenu = document.getElementById("programsMenu");

// Keep the Programs menu usable by mouse, keyboard, and touch.
programsButton.addEventListener("click", () => {
  const isOpen = programsMenu.classList.toggle("open");
  programsButton.setAttribute("aria-expanded", String(isOpen));
});

document.addEventListener("click", (event) => {
  if (!event.target.closest(".dropdown")) {
    programsMenu.classList.remove("open");
    programsButton.setAttribute("aria-expanded", "false");
  }
});

// Selecting BIT or BCS from the menu also selects it in the form.
programsMenu.querySelectorAll("[data-program]").forEach((item) => {
  item.addEventListener("click", () => {
    program.value = item.dataset.program;
    statusMessage.textContent = `${item.dataset.program} selected.`;
    statusMessage.className = "status-message success";
    programsMenu.classList.remove("open");
    programsButton.setAttribute("aria-expanded", "false");
  });
});

form.addEventListener("submit", (event) => {
  event.preventDefault();

  if (!form.reportValidity()) return;

  const selectedGender = form.querySelector('input[name="gender"]:checked');
  const selectedLanguages = Array.from(
    form.querySelectorAll('input[name="languages"]:checked')
  ).map((checkbox) => checkbox.value);

  const details = {
    firstName: firstName.value.trim(),
    lastName: lastName.value.trim(),
    gender: selectedGender ? selectedGender.value : "Not selected",
    program: program.value,
    languages: selectedLanguages.length ? selectedLanguages.join(", ") : "None selected",
    others: document.getElementById("others").value.trim() || "None"
  };

  // Build the result using textContent so user-entered text is not treated as HTML.
  submissionResult.replaceChildren();
  const heading = document.createElement("h2");
  heading.textContent = "Registration Details";
  submissionResult.appendChild(heading);

  const rows = [
    ["First Name", details.firstName],
    ["Last Name", details.lastName],
    ["Gender", details.gender],
    ["Program", details.program],
    ["Languages", details.languages],
    ["Others", details.others]
  ];

  rows.forEach(([label, value]) => {
    const paragraph = document.createElement("p");
    const strong = document.createElement("strong");
    strong.textContent = `${label}: `;
    paragraph.append(strong, document.createTextNode(value));
    submissionResult.appendChild(paragraph);
  });

  submissionResult.hidden = false;
  statusMessage.textContent = "Form submitted successfully in this browser.";
  statusMessage.className = "status-message success";
});

form.addEventListener("reset", () => {
  // Let the browser reset the controls first, then clear messages.
  window.setTimeout(() => {
    statusMessage.textContent = "";
    statusMessage.className = "status-message";
    submissionResult.hidden = true;
    submissionResult.replaceChildren();
    firstName.focus();
  }, 0);
});

exitButton.addEventListener("click", () => {
  const shouldExit = window.confirm("Are you sure you want to exit this form?");
  if (shouldExit) {
    form.reset();
    statusMessage.textContent = "Form cleared. You can close this browser tab when you are ready.";
    statusMessage.className = "status-message success";
    window.scrollTo({ top: 0, behavior: "smooth" });
  } else {
    statusMessage.textContent = "Exit cancelled.";
    statusMessage.className = "status-message";
  }
});

// Unlike the original Java code, first and last name remain independent fields.
